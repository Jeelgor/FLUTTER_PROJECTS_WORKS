import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:todo_app/models/todo.dart';

class APICALL {
  static addTask(int id, String task) async {
    var headers = {'Content-Type': 'application/json'};
    var request = http.Request(
        'POST', Uri.parse('https://node-todo-api-yjo3.onrender.com/todos/'));
    request.body = json.encode({"id": id, "Task": task});
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      print(await response.stream.bytesToString());
    } else {
      print(response.reasonPhrase);
    }
  }

  static fetchTask() async {
    http.Response response = await http.get(
      Uri.parse('https://node-todo-api-yjo3.onrender.com/todos/'),
    );

    if (response.statusCode == 200) {
      print(await response.body.toString());
      final todo = todoFromJson(response.body);
    } else {
      print(response.reasonPhrase);
    }
  }
}
